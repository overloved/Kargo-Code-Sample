<?php 

require_once 'BaseController.php';
require_once APPLICATION_PATH. '/models/Fruit.php';

/**
 * Show shopping list.
 * @author Yao
 *
 */
class MainController extends BaseController {
    
    /**
     * To shopping main center
     */
    public function mainAction() {
        #echo "ok";
        // create
        $fruitModel = new Fruit();
        $this->view->fruit = $fruitModel->fetchAll()->toArray();
        session_start();
        $this->view->login_user=$_SESSION['login_user'];
        $this->render('main');
    }
}
