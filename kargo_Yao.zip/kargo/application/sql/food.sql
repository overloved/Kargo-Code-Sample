/** store fruit info */
CREATE TABLE fruit (
	fruit_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	fruit_name VARCHAR(40) NOT NULL,
	fruit_price CHAR(20) NOT NULL,
	num_remain INT NOT NULL DEFAULT 0,
	PRIMARY KEY(fruit_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO fruit (fruit_name, fruit_price, num_remain) 
VALUES ('watermelon', '4.99/ea', '100');
INSERT INTO fruit (fruit_name, fruit_price, num_remain) 
VALUES ('strawberry', '5.99/pk', '100');
INSERT INTO fruit (fruit_name, fruit_price, num_remain) 
VALUES ('cherry', '9.99/pk', '50');
INSERT INTO fruit (fruit_name, fruit_price, num_remain) 
VALUES ('banana', '0.99/lb', '100');
INSERT INTO fruit (fruit_name, fruit_price, num_remain) 
VALUES ('red apple', '1.69/lb', '70');
INSERT INTO fruit (fruit_name, fruit_price, num_remain) 
VALUES ('green apple', '1.99/lb', '50');