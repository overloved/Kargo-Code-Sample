<?php 

  /**
   * Shopping cart object for user.
   * @author Yao
   *
   */
  class MyCart extends Zend_Db_Table {
      protected $_name = 'cart';
      protected $_primary = 'cart_id'; 
      var $total_price = 0;
      
      /**
       * Add goods into shopping cart.
       * params $user_id The current user.
       * params $product_id The product should be added into the shopping cart.
       * params $num The num of product should be added. Default is 1.
       */ 
      function addProduct($user_id, $product_id, $num=1) {
          
          $res = $this->fetchAll("user_id = $user_id AND fruit_id = $product_id")->toArray();
          
          if (count($res) > 0) {
              
              // The good has already existed in user's cart, then update quantity instead.
              $quantity = $res[0]['num'];
              $data = array(
                'num' => $quantity + 1	    
              );
              
              $where = "user_id = $user_id AND fruit_id = $product_id";
              $this->update($data, $where);
              
              return;
          }
      
          $now = time();
          
          $data = array(
          	'user_id'    => $user_id,
            'fruit_id'   => $product_id,     
            'num'        => $num,
            'cart_date'  => $now 
          );
          
          if ($this->insert($data) > 0) {
              return true;
          }
          else {
              return false;
          }
      }
      
      /**
       * Show user's shopping cart
       * params $user_id The current user.
       */ 
      function showMyCart($user_id) {
          
          $sql = "SELECT f.fruit_id, f.fruit_name, f.fruit_price, c.num 
                  FROM fruit f, cart c 
                  WHERE c.fruit_id = f.fruit_id";
          $db = $this->getAdapter();
          $res = $db->query($sql)->fetchAll();
          
          for ($i = 0; $i < count($res); $i++) {
              $bookinfo = $res[$i];
              $this->total_price += $bookinfo['fruit_price']*$bookinfo['num'];
          }
          
          return $res;
      }
      
      /**
       * Delete goods from shopping cart.
       * params $user_id The current user.
       * params $product_id The product should be removed from the shopping cart. 
       */ 
      function deleteProduct($user_id, $product_id) {
          if ($this->delete("user_id = $user_id AND fruit_id = $product_id") > 0) {
              return true;
          }
          else {
              return false;
          }
      }
      
      /**
       * Update goods from the shopping cart.
       */ 
      function updateProduct($user_id, $product_id, $newNum) {
          $set = array(
          	'num' => $newNum
          );
          $where = "user_id = $user_id AND fruit_id = $product_id";
          $this->update($set, $where);
      }
      
      /** 
       * calculate the total price of the current shopping cart.
       */
      function getTotalPrice() {
          return $this->total_price;
      }
      
  }

?>