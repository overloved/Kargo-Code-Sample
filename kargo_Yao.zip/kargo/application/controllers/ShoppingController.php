<?php

require_once 'BaseController.php';
require_once APPLICATION_PATH.'/models/MyCart.php';

/**
 * Controll the main actions for products.
 * @author Yao
 *
 */
class ShoppingController extends BaseController {
    
    /**
     * Add product into user's shopping cart.
     */
    public function addproductAction() {
        // get product id       
        $product_id = $this->getRequest()->getParam('productid');
        
        // create cart model      
        $mycart = new MyCart();
        session_start();
        
        if ($mycart->addProduct($_SESSION['login_user']['user_id'], $product_id)) {
            $this->view->info = 'You have successfully added this item.';
            $this->view->redirect = "/main/main";
            $this->_forward('success', 'global');
        }
        else {
            $this->view->info = 'You cannot add this item.';
            $this->view->redirect = "/main/main";
            $this->_forward('fail', 'global');
        }
    }
    
    /**
     * Show user's shopping cart.
     */
    public function mycartAction() {
        $mycart = new MyCart();
        session_start();
        $this->view->product = $mycart->showMyCart($_SESSION['login_user']['user_id']);
        $this->view->total_price = $mycart->getTotalPrice();
        $this->render('mycart');
    }
    
    /**
     * Update goods in the shopping cart.
     */
    public function updatecartAction() {
       $product_ids = $this->getRequest()->getParam('fruitids');
       $product_nums = $this->getRequest()->getParam('fruitnums');
     
       $mycart = new MyCart();
       session_start();
       $user_id = $_SESSION['login_user']['user_id'];
       
       for ($i = 0; $i < count($product_ids); $i++) {
           $mycart->updateProduct($user_id, $product_ids[$i], $product_nums[$i]);
       }
       
       $this->view->info = 'You have updated this item.';
       $this->view->redirect="/shopping/mycart";
       $this->_forward('success', 'global');
    }

    /**
     * Delete product from user's shopping cart.
     */
    public function deleteproductAction() {
        // get product id
        $id = $this->getRequest()->getParam("id");
        $mycart = new MyCart();
        session_start();
        
        if ($mycart->deleteProduct($_SESSION['login_user']['user_id'], $id)) {
           $this->view->info = 'You have successfully deleted this item.';
           $this->view->redirect="/shopping/mycart";
           $this->_forward('success', 'global');         
        }
        else {
            $this->view->info = 'You did not delete this item.';
            $this->view->redirect="/shopping/mycart";
            $this->_forward('fail', 'global');
        }
    }
    
}