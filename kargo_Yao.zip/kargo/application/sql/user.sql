/** store user info */
CREATE TABLE user (
	user_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	username VARCHAR(40) NOT NULL,
	password CHAR(40) NOT NULL,
	firstName VARCHAR(20) NOT NULL,
	lastName VARCHAR(20) NOT NULL,
	email VARCHAR(255) NOT NULL,
	PRIMARY KEY(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO user (username, password, firstName, lastName, email) 
VALUES ('admin', '1234', 'Yao', 'Huang', 'yao.engineering@gmail.com');