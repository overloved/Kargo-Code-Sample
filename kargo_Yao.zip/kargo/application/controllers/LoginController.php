<?php 

require_once 'BaseController.php';
require_once APPLICATION_PATH.'/models/Users.php';
/**
 * 
 * LoginController is to respond the login and logout request.
 * @author Yao
 *
 */
class LoginController extends BaseController {
    
    public function loginAction() {
        
        // Call login form
        $userModel = new Users();
        // fetch the username and pwd of the user
        $username = $this->getRequest()->getParam("username");
        $password = $this->getRequest()->getParam("password");
        
        $db = $userModel->getAdapter();
        $where = $db->quoteInto("username=?", $username)
        .$db->quoteInto(" AND password=?", $password);
        
        $login_user = $userModel->fetchAll($where)->toArray();
        
        if (count($login_user) == 1) {
            // If has user, get the user info, save it into session.
            session_start();
            $_SESSION['login_user'] = $login_user[0];
            //action, controller
            $this->_forward('main', 'main');
        }
        else {
            // If doesn't have user, error info.
            $this->view->err = "username or password is wrong";
            $this->_forward('index', 'index');
        }
    }
    
    public function logoutAction() {
        
    }
    
}
