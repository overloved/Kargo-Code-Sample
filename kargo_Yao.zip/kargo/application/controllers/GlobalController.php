<?php

/**
 * To realize the global function.
 * @author Yao
 *
 */
class GlobalController extends BaseController {
    /**
     * Show info when the current action is able to process.
     */
    public function successAction() {
        
    }

    /**
     * Show info when the current action is unable to process.
     */
    public function failAction() {
        
    }
    
}