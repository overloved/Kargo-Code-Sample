<?php 
    /**
     * User model.
     * @author Yao
     *
     */
    class Users extends Zend_Db_Table {
        
        protected $_name = 'user';
        protected $_primary = 'user_id';
        
    }
