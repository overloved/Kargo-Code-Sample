/** Cart sql is to show those goods the user wants to buy */
CREATE TABLE cart (
	cart_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	user_id INT UNSIGNED NOT NULL,
	fruit_id INT UNSIGNED NOT NULL,
	num INT UNSIGNED NOT NULL,
	cart_date DATETIME NOT NULL,
	PRIMARY KEY(cart_id),
	FOREIGN KEY(user_id) REFERENCES user(user_id),
	FOREIGN KEY(fruit_id) REFERENCES fruit(fruit_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

