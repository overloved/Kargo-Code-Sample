<?php 
    /**
     * Shopping product model.
     * @author Yao
     *
     */
    class Fruit extends Zend_Db_Table {
        
        protected $_name = 'fruit';
        protected $_primary = 'fruit_id';
        
    }
